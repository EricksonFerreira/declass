<?php

namespace App\Http\Controllers;

// Exceptions
use App\Exceptions\ClienteNaoEncontradoException;
use App\Exceptions\MultiplosClientesComEmailException;

use App\Http\Controllers\Interfaces\FiltroInterface;
use App\Http\Controllers\Interfaces\ResourceInterface;
use App\Http\Requests\Usuario\StoreUsuarioRequest;
use App\Http\Requests\Usuario\UpdatePasswordUsuarioRequest;
use App\Http\Requests\Usuario\UpdateUsuarioRequest;
use App\Models\Pais;
use App\Models\User;
use App\Services\BreadcrumbService;
use App\Services\EstacaoService;
use App\Services\PaisService;
use App\Services\RegraService;
use App\Services\UsuarioService;
use App\Traits\AtualizaFiltrosTrait;
use Illuminate\Http\Request;
use App\Traits\FiltroTrait;
use App\Services\ClienteStripeService;

class UsuarioController extends BaseController implements FiltroInterface, ResourceInterface
{
    use FiltroTrait;
    use AtualizaFiltrosTrait;
    protected $usuarioService;
    protected $breadcrumbService;
    protected $regraService;
    protected $paisService;
    protected $estacaoService;
    protected $clienteStripeService;

    public function __construct(
        UsuarioService $usuarioService,
        BreadcrumbService $breadcrumbService,
        RegraService $regraService,
        PaisService $paisService,
        EstacaoService $estacaoService,
        ClienteStripeService $clienteStripeService
    ) {
        $this->titulo = "Usuários";
        $this->nomeFiltro = 'usuario';
        $this->usuarioService = $usuarioService;
        $this->breadcrumbService = $breadcrumbService;
        $this->regraService = $regraService;
        $this->paisService = $paisService;
        $this->estacaoService = $estacaoService;
        $this->clienteStripeService = $clienteStripeService;
    }

    public function index()
    {
        $this->configurarSessao();

        $itensFiltered = session("$this->nomeFiltro.filtro", []);
        $perPage = session()->get("$this->nomeFiltro.perPage", 10);

        // session()->forget("$this->nomeFiltro.filtro");
        $usuarios = $this->usuarioService->getAllWithFiltersAndPagination($itensFiltered, $perPage, ['tipoUsuario']);

        $breadcrumb = $this->breadcrumbService->prepararBreadcrumbIndex('Usuarios');
        $filters = $this->obterFiltrosPrincipais();
        $additionalFilters = $this->obterFiltrosSecundarios();

        $this->atualizarFiltros($itensFiltered, $filters);
        $this->atualizarFiltros($itensFiltered, $additionalFilters);

        $perPages = [5, 10, 15, 25, 50, 100];

        $nomeFiltro = $this->nomeFiltro;

        return view('usuario.index', compact(
            'usuarios',
            'breadcrumb',
            'filters',
            'itensFiltered',
            'additionalFilters',
            'perPages',
            'perPage',
            'nomeFiltro'
        ))->with('titulo', $this->titulo);
    }

    public function create()
    {
        $sexo = [
            'M' => 'Masculino',
            'F' => 'Feminino',
            'O' => 'Outro'
        ];
        $breadcrumb = $this->breadcrumbService->prepararBreadcrumbCreate('Usuarios', 'usuario.index', 'Criar');

        $paises = $this->paisService->getAllForSelectSigla();
        $estacoes = $this->estacaoService->getAllAtivos();

        $tiposUsuario = $this->regraService->getAllTiposUsuarios();
        [$metodo, $rota] = $this->getFormMethodAndRoute();
        $acessoTodasEstacoes = true;
        $estacoesSelecionadas = [];

        return view('usuario.add-edit', compact('breadcrumb', 'sexo', 'metodo', 'tiposUsuario', 'paises', 'estacoes', 'acessoTodasEstacoes', 'estacoesSelecionadas', 'rota'))->with('titulo', $this->titulo);
    }

    public function store(StoreUsuarioRequest $request)
    {
        try {
            // Remove o campo de confirmacao de senha
            $data = $request->except('confirmacao_senha');
            $isCadastroReserva = $request->boolean('cadastro_reserva');

            if ($isCadastroReserva) {
                $roleClienteId = $this->regraService->getClienteRoleId();
                if (!$roleClienteId) {
                    $errors = [
                        'role_id' => ['Cadastre uma regra "Cliente" para permitir cadastro rapido na reserva.'],
                    ];

                    if ($request->expectsJson()) {
                        return response()->json([
                            'message' => 'Nao foi encontrada uma regra Cliente para sua empresa.',
                            'errors' => $errors,
                        ], 422);
                    }

                    return redirect()
                        ->back()
                        ->withInput()
                        ->withErrors($errors);
                }

                $data['role_id'] = $roleClienteId;
                $data['acesso_todas_estacoes'] = true;
                $data['password'] = 'Tmp@' . random_int(100000, 999999);
            }

            // Cria o cliente no Stripe
            $cliente = $this->clienteStripeService->criarCliente($data['email'], $data['nome']);

            // Cria o usuario no sistema
            $data['stripe_id'] = $cliente->id;
            $usuario = $this->usuarioService->createUser($data);

            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Usuario cadastrado com sucesso.',
                    'usuario' => [
                        'id' => (int) $usuario->id,
                        'nome' => (string) $usuario->nome,
                        'email' => (string) $usuario->email,
                    ],
                ], 201);
            }

            return $this->redirecionaRotaRedirect($this->nomeFiltro);
        } catch (\Throwable $e) {
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Nao foi possivel cadastrar o usuario no momento.',
                    'error' => config('app.debug') ? $e->getMessage() : null,
                ], 422);
            }

            return redirect()
                ->back()
                ->withInput()
                ->withErrors(['usuario' => 'Nao foi possivel cadastrar o usuario no momento.']);
        }
    }

    public function selectOptions(Request $request)
    {
        $usuarios = collect($this->usuarioService->getAllForSelect())
            ->map(fn ($nome, $id) => ['id' => (int) $id, 'nome' => (string) $nome])
            ->sortBy('nome', SORT_NATURAL | SORT_FLAG_CASE)
            ->values();

        return response()->json([
            'usuarios' => $usuarios,
        ]);
    }

    public function edit($id)
    {
        $usuario = $this->usuarioService->getById($id);
        if (!$usuario) {
            abort(403, 'Sem acesso a este usuario.');
        }

        try {
            $metodosPagamento = $usuario->stripe_id
                ? $this->clienteStripeService->listarMetodosPagamento($usuario->stripe_id)
                : [];
        } catch (\Stripe\Exception\InvalidRequestException $e) {
            $metodosPagamento = [];
        }

        $sexo = [
            'M' => 'Masculino',
            'F' => 'Feminino',
            'O' => 'Outro'
        ];

        $tiposUsuario = $this->regraService->getAllTiposUsuarios();

        $paises = $this->paisService->getAllForSelectSigla();
        $estacoes = $this->estacaoService->getAllAtivos();
        $acessoTodasEstacoes = $usuario->hasAcessoTodasEstacoes();
        $estacoesSelecionadas = $usuario->estacoesPermitidas()->pluck('estacoes.id')->map(fn ($id) => (int) $id)->all();
        $breadcrumb = $this->breadcrumbService->prepararBreadcrumbEdit('Usuarios', 'usuario.index', "Editar: $usuario->nome");
        [$metodo, $rota] = $this->getFormMethodAndRoute($usuario);

        return view('usuario.add-edit', compact('metodosPagamento', 'usuario', 'breadcrumb', 'tiposUsuario', 'sexo', 'paises', 'estacoes', 'acessoTodasEstacoes', 'estacoesSelecionadas', 'metodo', 'rota'))->with('titulo', $this->titulo);
    }

    public function update(UpdateUsuarioRequest $request, $id)
    {
        $usuario = $this->usuarioService->getById($id);
        if (!$usuario) {
            abort(403, 'Sem acesso para editar este usuario.');
        }

        // if (isset($request->stripeToken)) {
        //     $cliente = $this->clienteStripeService->getClienteByEmail($usuario->email);

        //     if ($cliente->data == []) {
        //         throw new ClienteNaoEncontradoException();
        //     }

        //     if (count($cliente->data) > 1) {
        //         throw new MultiplosClientesComEmailException();
        //     }

        //     $cliente = $cliente->data[0];
        //     $this->clienteStripeService->createPaymentMethod($cliente->id, $request->stripeToken);
        // }

        $this->usuarioService->updateUser($id, $request->all());
        return $this->redirecionaRotaRedirect($this->nomeFiltro);
    }

    public function metodoPagamento($usuarioId)
    {
        $usuario = $this->usuarioService->getById($usuarioId);
        if (!$usuario) {
            abort(403, 'Sem acesso a este usuario.');
        }

        if($usuario->stripe_id == null){
            return $this->redirecionaRotaRedirect('usuario.index', 'UsuÃ¡rio nÃ£o possui cÃ³digo Stripe','error');
        }

        $metodosPagamento = $this->clienteStripeService->listarMetodosPagamento($usuario->stripe_id);

        $breadcrumb = $this->breadcrumbService->prepararBreadcrumbEdit('Usuarios', 'usuario.index', "Editar: $usuario->nome");
        $metodo = 'POST';
        $rota = route('usuario.adicionarMetodoPagamento', $usuarioId);

        return view(
            'usuario.metodoPagamento',
            compact(
                'metodosPagamento',
                'breadcrumb',
                'usuarioId',
                'metodo',
                'rota'
            )
        )
            ->with('titulo', 'MÃ©todos de Pagamento');
    }

    public function adicionarMetodoPagamento(Request $request, $usuarioId)
    {
        if (isset($request->stripeToken)) {

            $usuario = $this->usuarioService->getById($usuarioId);
            if (!$usuario) {
                abort(403, 'Sem acesso a este usuario.');
            }
            // $cliente = $this->clienteStripeService->getClienteByEmail($usuario->email);
            $this->clienteStripeService->criarMetodoPagamento($usuario->stripe_id, $request->stripeToken);
            return $this->redirecionaRotaRedirect('usuario.metodoPagamento', 'MÃ©todo de pagamento adicionado com sucesso!');
        }

        return $this->redirecionaRotaRedirect('usuario.metodoPagamento', 'MÃ©todo de pagamento nÃ£o adicionado!', 'error');
    }

    public function excluirMetodoPagamento($usuarioId, $metodoId)
    {
        $this->clienteStripeService->deletarMetodoPagamento($metodoId);
        return $this->redirecionaRotaRedirect('usuario.metodoPagamento', 'Metodo de pagamento excluido com sucesso!');
    }

    public function alterarSenha($id)
    {
        $usuario = $this->usuarioService->getById($id);
        if (!$usuario) {
            abort(403, 'Sem acesso a este usuario.');
        }
        $breadcrumb = $this->breadcrumbService->prepararBreadcrumbEdit('Usuarios', 'usuario.index', "Alterar Senha: $usuario->nome");
        $metodo = 'PUT';
        $rota = route('usuario.salvarNovaSenha', $usuario->id);

        return view('usuario.alterar-senha', compact('usuario', 'breadcrumb', 'metodo', 'rota'))->with('titulo', $this->titulo);
    }

    public function salvarNovaSenha(UpdatePasswordUsuarioRequest $request, $id)
    {
        $resetarParaAcesso = $request->boolean('resetar_para_acesso');

        $this->usuarioService->updatePassword($id, [
            'password' => $request->input('password'),
            'forcar_troca_senha' => $resetarParaAcesso,
        ]);

        $mensagem = $resetarParaAcesso
            ? 'Senha resetada para car@12345. No primeiro login o usuario sera obrigado a definir uma nova senha.'
            : 'Senha alterada com sucesso.';

        if ($request->expectsJson()) {
            return response()->json(['message' => $mensagem]);
        }

        return $this->redirecionaRotaRedirect($this->nomeFiltro, $mensagem);
    }

    public function destroy($id)
    {
        $success = $this->usuarioService->delete($id);
        if (!$success) {
            abort(403, 'Sem acesso para excluir este usuario.');
        }
        return $this->redirecionaRotaRedirect($this->nomeFiltro);
    }

    public function filtro(Request $request)
    {
        $this->criarFiltros($request, $this->nomeFiltro);
        return $this->redirecionaRotaRedirect($this->nomeFiltro);
    }

    public function removerFiltro(Request $request)
    {
        $atributo = $request->input('atributo') ?? null;
        $this->removeSessao($this->nomeFiltro, $atributo);
        return $this->redirecionaRotaRedirect($this->nomeFiltro);
    }

    public function setPerPage(Request $request)
    {
        // Salva o valor de paginaÃ§Ã£o na sessÃ£o
        $request->session()->put("$this->nomeFiltro.perPage", $request->input('perPage'));

        // Redireciona de volta para a pÃ¡gina de listagem
        return $this->redirecionaRotaRedirect($this->nomeFiltro);
    }

    public function configurarSessao()
    {
        session()->put("$this->nomeFiltro.urlPadrao", 'usuario');
        session()->put("$this->nomeFiltro.rotaRedirect", 'usuario.index');
    }

    public function obterFiltrosPrincipais()
    {
        $tiposUsuarios = $this->regraService->getAllTiposUsuarios();
        $dataTiposUsuarios = [];
        $dataTiposUsuarios[] = ['value' => '', 'label' => 'Selecione o status', 'selected' => false];

        foreach ($tiposUsuarios as $key => $value) {
            $dataTiposUsuarios[] = ['value' => $key, 'label' => $value, 'selected' => false];
        }
        return [
            ['name' => 'nome', 'label' => 'Nome', 'type' => 'text', 'typeWhere' => 'like'],
            ['name' => 'email', 'label' => 'E-mail', 'type' => 'text', 'typeWhere' => 'like'],
            ['name' => 'celular', 'label' => 'Celular', 'type' => 'text', 'typeWhere' => 'like'],
            ['name' => 'cidade', 'label' => 'Cidade', 'type' => 'text', 'typeWhere' => 'like'],
            ['name' => 'role_id', 'label' => 'Regra de UsuÃ¡rio', 'type' => 'select', 'typeWhere' => 'where', 'options' => $dataTiposUsuarios],
        ];
    }

    public function obterFiltrosSecundarios()
    {
        return [
            // Adicione filtros secundÃ¡rios aqui, se necessÃ¡rio
        ];
    }

    /**
     * FunÃ§Ã£o para obter o mÃ©todo e a rota para o formulÃ¡rio.
     *
     * @param  User|null  $usuario
     * @return array
     */
    private function getFormMethodAndRoute($usuario = null)
    {
        if ($usuario) {
            return [
                'PUT',
                route('usuario.update', $usuario->id),
            ];
        }

        return [
            'POST',
            route('usuario.store'),
        ];
    }
}
