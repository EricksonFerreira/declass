@extends('adminlte::page')

@section('title', $titulo)

@section('content_header')
    <x-breadcrumb :breadcrumbs="$breadcrumb" />
    <x-page-title :title="$titulo" />
@stop

@section('content')
    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-8  col-xs-12 card p-2">
        <div class="card-body">
            <x-form method="{{$metodo}}" action="{{ $rota }}" rowClass="row">
            <div class="col pl-0">
                <div class="form-group">
                    <x-form-input type="text" class="form-control form-control-sm" id="nome" name="nome"
                        label="Nome" value="{{ $tipotransacao->nome ?? '' }}" required />
                </div>
            </div>
            <div class="col pr-0">

                <div class="form-group">
                    <x-form-select name="ativo" label="Status" :options="$status" placeholder="Selecione um valor"
                        :selected="$tipotransacao->ativo ?? ''" class="form-control form-control-sm" required />
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-xs col-12">
                Salvar
            </button>
            </x-form>
        </div>
    </div>

    </div>
@stop


@section('js')
    <script></script>
@stop
