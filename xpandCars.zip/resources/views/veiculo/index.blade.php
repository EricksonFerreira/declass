@extends('adminlte::page')

@section('title', $titulo)

@section('content_header')
    <x-breadcrumb :breadcrumbs="$breadcrumb" />
    <x-page-title :title="$titulo" :createUrl="route('veiculo.create')" />
@stop

@section('content')
    @if (isset($filters) && is_array($filters) && count($filters) > 0)
        <x-filter :additionalFilters="$additionalFilters" :filters="$filters" :itensFiltered="$itensFiltered" />
    @endif
    <div class="card p-2">
        <div class="card-header px-0 pt-0 pb-1">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="card-title text-sm text-bold">REGISTROS <span
                        class="badge badge-success">{{ $veiculos->total() }}</span></h3>
                <div class="align-bottom d-flex flex-row justify-between">
                    <form action="{{ route('veiculo.setPerPage') }}" method="POST">
                        @csrf
                        <x-per-page-selector :perPages="$perPages" :selectedPerPage="$perPage" />
                    </form>
                    <div class="d-flex align-items-end">
                        {{ $veiculos->links() }}
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body px-0 pt-0 pb-1 table-responsive">

            <table class="table table-striped table-bordered table-sm">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Tipo de Frota</th>
                        <th>Grupo de Frota</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Status</th>
                        <th>Local Disponível Inicial</th>
                        <th style="width: 180px;">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($veiculos as $veiculo)
                        <tr>
                            <td>{{ $veiculo->nome }}</td>
                            <td>{{ $veiculo->tipoFrota?->nome }}</td>
                            <td>{{ $veiculo->grupoFrota?->nome }}</td>
                            <td>{{ $veiculo->marca?->nome }}</td>
                            <td>{{ $veiculo->modelo?->nome }}</td>
                            <td>{{ $veiculo->statusVeiculo?->nome }}</td>
                            @php
                                $dataHoraAtual = now();
                            @endphp

                            <td>
                                @if ($veiculo->data_hora_disponibilidade)
                                    @if ($veiculo->data_hora_disponibilidade <= $dataHoraAtual)
                                        {{ $veiculo->localDisponibilidade?->nome }} - {{\Carbon\Carbon::parse($veiculo->data_hora_disponibilidade)->format('d/m/Y H:i')}} <span
                                            class="badge badge-xs bg-green">Disponível</span>
                                    @else
                                        {{ $veiculo->localDisponibilidade?->nome }} - {{\Carbon\Carbon::parse($veiculo->data_hora_disponibilidade)->format('d/m/Y H:i')}} <span
                                            class="badge badge-xs bg-red">Indisponível</span>
                                    @endif
                                @else
                                    <span
                                        class="badge badge-xs bg-red">Indisponível</span>
                                @endif
                            </td>
                            <td style="width: 180px;">
                                <a href="{{ route('veiculo.edit', $veiculo->id) }}" class="btn btn-xs btn-warning"><i
                                        class="fa fa-edit"></i> Editar</a>
                                <x-delete-button :action="route('veiculo.destroy', $veiculo->id)" />
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@stop

@section('js')
    <script></script>
@stop
