<ol class="breadcrumb page_bradcam mb-0">
    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item <?php echo e($loop->last ? 'active' : ''); ?>">
            <?php if(!$loop->last): ?>
                <a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['name']); ?></a>
            <?php else: ?>
                <?php echo e($breadcrumb['name']); ?>

            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>
<?php /**PATH C:\Users\Erickson\Dev\laragon\www\xpandCars\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>