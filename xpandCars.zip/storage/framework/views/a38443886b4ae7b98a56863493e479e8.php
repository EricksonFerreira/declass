<div class="d-flex justify-content-between align-items-center">
    <h3 class="mb-0 font-weight-bold"><?php echo e($title); ?></h3>
    <?php if(isset($createUrl) && $createUrl && (!isset($createCan) || (auth()->check() && auth()->user()->hasPermissao($createCan)))): ?>
        <a href="<?php echo e($createUrl); ?>" class="btn btn-xs btn-primary"><i class="fa fa-plus" style="font-size:10px"></i> Adicionar</a>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Erickson\Dev\laragon\www\xpandCars\resources\views/components/page-title.blade.php ENDPATH**/ ?>