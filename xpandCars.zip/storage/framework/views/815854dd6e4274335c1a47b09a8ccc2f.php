<?php
    $empresaTemaAtual = null;
    $empresaSelecionada = 0;

    if (Auth::check() && \Illuminate\Support\Facades\Schema::hasTable('empresas')) {
        $empresaIdTema = null;

        if (Auth::user()->isAdministrador()) {
            $empresaIdSessao = (int) session('empresa_context_id', 0);
            $empresaSelecionada = $empresaIdSessao;
            if ($empresaIdSessao > 0) {
                $empresaIdTema = $empresaIdSessao;
            }
        } else {
            $empresaIdTema = (int) (Auth::user()->empresa_id ?? 0);
            $empresaSelecionada = $empresaIdTema;
        }

        if ($empresaIdTema) {
            $empresaTemaAtual = \App\Models\Empresa::query()
                ->select(['id', 'nome', 'logo_path', 'cor_primaria', 'cor_secundaria', 'cor_terciaria'])
                ->find($empresaIdTema);
        }
    }
?>

<style>
    :root {
        --empresa-cor-primaria: <?php echo e($empresaTemaAtual->cor_primaria ?? '#1F2937'); ?>;
        --empresa-cor-secundaria: <?php echo e($empresaTemaAtual->cor_secundaria ?? '#E2E8F0'); ?>;
        --empresa-cor-terciaria: <?php echo e($empresaTemaAtual->cor_terciaria ?? '#64748B'); ?>;
    }

    /* Sidebar search: keep typed match text readable on light results panel */
    .main-sidebar .sidebar-search-results .search-title,
    .main-sidebar .sidebar-search-results .search-path {
        color: #111827 !important;
    }

    .main-sidebar .sidebar-search-results .search-title .text-light,
    .main-sidebar .sidebar-search-results .search-path .text-light,
    .main-sidebar .sidebar-search-results .search-title strong,
    .main-sidebar .sidebar-search-results .search-path strong {
        color: #000 !important;
        font-weight: 700 !important;
    }
</style>

<?php if($empresaTemaAtual): ?>
    <style>
        body:not(.login-page) .content-wrapper {
            background-image: linear-gradient(
                135deg,
                color-mix(in srgb, var(--empresa-cor-primaria) 16%, white 84%) 0%,
                color-mix(in srgb, var(--empresa-cor-secundaria) 14%, white 86%) 55%,
                color-mix(in srgb, var(--empresa-cor-terciaria) 12%, white 88%) 100%
            );
            background-attachment: fixed;
        }

        body:not(.login-page) .main-header.navbar {
            background: var(--empresa-cor-primaria) !important;
            border-bottom: 2px solid color-mix(in srgb, var(--empresa-cor-terciaria) 60%, #0f172a 40%);
        }

        body:not(.login-page) .main-header.navbar .nav-link,
        body:not(.login-page) .main-header.navbar .navbar-nav .nav-link i {
            color: var(--empresa-cor-secundaria) !important;
        }

        body:not(.login-page) .main-sidebar {
            background: var(--empresa-cor-primaria) !important;
        }

        body:not(.login-page) .main-sidebar .brand-text,
        body:not(.login-page) .main-sidebar .nav-sidebar .nav-link,
        body:not(.login-page) .main-sidebar .nav-header,
        body:not(.login-page) .main-sidebar .user-panel .info,
        body:not(.login-page) .main-sidebar .user-panel .info a {
            color: var(--empresa-cor-secundaria) !important;
        }

        body:not(.login-page) .main-sidebar .nav-sidebar .nav-link.active,
        body:not(.login-page) .main-sidebar .nav-sidebar .nav-link:hover {
            background: color-mix(in srgb, var(--empresa-cor-terciaria) 35%, transparent 65%) !important;
            color: var(--empresa-cor-secundaria) !important;
        }

        body:not(.login-page) .main-sidebar .nav-item.menu-open > .nav-treeview > .nav-item > .nav-link {
            background: color-mix(in srgb, var(--empresa-cor-secundaria) 16%, transparent 84%) !important;
            border-radius: .35rem;
            margin: 2px 6px;
        }

        body:not(.login-page) .main-sidebar .nav-item.menu-open > .nav-treeview > .nav-item > .nav-link.active {
            background: color-mix(in srgb, var(--empresa-cor-terciaria) 55%, transparent 45%) !important;
            font-weight: 700;
        }

        body:not(.login-page) .main-header.navbar {
            border-bottom: 2px solid color-mix(in srgb, var(--empresa-cor-primaria) 35%, #dbe5f0 65%);
        }

        .empresa-context-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            max-width: 260px;
            padding: .3rem .6rem;
            border-radius: 999px;
            background: color-mix(in srgb, var(--empresa-cor-terciaria) 35%, #0f172a 65%);
            color: var(--empresa-cor-secundaria);
            font-size: 12px;
            line-height: 1;
        }

        .empresa-context-chip img {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            object-fit: contain;
            background: var(--empresa-cor-primaria);
            border: 1px solid color-mix(in srgb, var(--empresa-cor-secundaria) 25%, transparent 75%);
            padding: 1px;
        }

        .empresa-context-chip .empresa-chip-inicial {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: var(--empresa-cor-secundaria);
            color: var(--empresa-cor-primaria);
            font-weight: 700;
        }
    </style>
<?php endif; ?>

<nav class="main-header navbar
    <?php echo e(config('adminlte.classes_topnav_nav', 'navbar-expand')); ?>

    <?php echo e(config('adminlte.classes_topnav', 'navbar-white navbar-light')); ?>">

    
    <ul class="navbar-nav">
        
        <?php echo $__env->make('adminlte::partials.navbar.menu-item-left-sidebar-toggler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->renderEach('adminlte::partials.navbar.menu-item', $adminlte->menu('navbar-left'), 'item'); ?>

        
        <?php echo $__env->yieldContent('content_top_nav_left'); ?>
    </ul>

    
    <ul class="navbar-nav ml-auto">
        <?php if($empresaTemaAtual): ?>
            <li class="nav-item d-flex align-items-center mr-2">
                <span class="empresa-context-chip" title="Empresa ativa">
                    <?php if(!empty($empresaTemaAtual->logo_path) && \Illuminate\Support\Facades\Storage::disk('public')->exists($empresaTemaAtual->logo_path)): ?>
                        <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($empresaTemaAtual->logo_path)); ?>" alt="Logo empresa">
                    <?php else: ?>
                        <span class="empresa-chip-inicial"><?php echo e(strtoupper(mb_substr($empresaTemaAtual->nome ?? 'E', 0, 1))); ?></span>
                    <?php endif; ?>
                    <span class="text-truncate"><?php echo e($empresaTemaAtual->nome); ?></span>
                </span>
            </li>
        <?php endif; ?>

        <?php if(Auth::check() && Auth::user()->isAdministrador() && \Illuminate\Support\Facades\Schema::hasTable('empresas')): ?>
            <?php
                $empresasMenu = \App\Models\Empresa::query()->orderBy('nome')->pluck('nome', 'id')->toArray();
            ?>
            <li class="nav-item d-flex align-items-center mr-2">
                <form method="POST" action="<?php echo e(route('empresa_context.update')); ?>" class="mb-0">
                    <?php echo csrf_field(); ?>
                    <select
                        name="empresa_id"
                        class="form-control form-control-sm"
                        style="min-width: 220px;"
                        onchange="this.form.submit()"
                        title="Empresa em visualização"
                    >
                        <option value="0" <?php echo e($empresaSelecionada === 0 ? 'selected' : ''); ?>>Todas as empresas</option>
                        <?php $__currentLoopData = $empresasMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresaId => $empresaNome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($empresaId); ?>" <?php echo e($empresaSelecionada === (int) $empresaId ? 'selected' : ''); ?>>
                                <?php echo e($empresaNome); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </li>
        <?php endif; ?>

        
        <?php echo $__env->yieldContent('content_top_nav_right'); ?>

        
        <?php echo $__env->renderEach('adminlte::partials.navbar.menu-item', $adminlte->menu('navbar-right'), 'item'); ?>

        
        <?php if(Auth::user()): ?>
            <?php if(config('adminlte.usermenu_enabled')): ?>
                <?php echo $__env->make('adminlte::partials.navbar.menu-item-dropdown-user-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('adminlte::partials.navbar.menu-item-logout-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php if(config('adminlte.right_sidebar')): ?>
            <?php echo $__env->make('adminlte::partials.navbar.menu-item-right-sidebar-toggler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </ul>

</nav>
<?php /**PATH C:\Users\Erickson\Dev\laragon\www\xpandCars\resources\views/vendor/adminlte/partials/navbar/navbar.blade.php ENDPATH**/ ?>